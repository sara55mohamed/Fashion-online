<!DOCTYPE html>
<html>
<head>
    <title>Shop</title>
    <link rel="stylesheet" href="css/catocrydetails.css">
</head>
<body>
    <!-- Header -->
    <div class="nav">
        <div class="content">
            <div class="logo">
                <a href="index.php"> <img src="img/logo.png"></a>
            </div>
            <div class="menu">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li class="drop">
                        <a>Shop</a>
                        <ul class="list">
                            <li><a href="shopcatogry.php">category</a></li>
                            <li><a href="catocrydetails.php">products</a></li>
                        </ul>
                    </li>
                    <li class="drop">
                        <a href="#">pages</a>
                        <ul class="list">
                            <li><a href="#">login</a></li>
                            <li><a href="#">checkout</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="search">
                
                <input type="search"> 
                <a href="#"><i></i></a>
            </div>
        </div>
    </div>
    <br/>
        <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>

    <div class="body">
                    <div class="pagename1">HOME /  catocry details</div>
                    
                    
                    <div class="frist_div">

                        <div class="frist_left">
                        


<div class="container">
  <div class="mySlides">
    <div class="numbertext">1 / 4</div>
    <img src="img/product_details/prodect_details_1.png" style="width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">2 / 4</div>
    <img src="img/product_details/prodect_details_2.png" style="width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">3 / 4</div>
    <img src="img/product_details/prodect_details_3.png" style="width:100%">
  </div>
    
  <div class="mySlides">
    <div class="numbertext">4 / 4</div>
    <img src="img/product_details/prodect_details_4.png" style="width:100%">
  </div>


    
  
    
  <a class="prev" onclick="plusSlides(-1)">❮</a>
  <a class="next" onclick="plusSlides(1)">❯</a>

    
  <div class="caption-container">
    <p id="caption"></p>
  </div>

  <div class="row">
    <div class="column">
      <img class="demo cursor" src="img/product_details/prodect_details_1.png" style="width:100%" onclick="currentSlide(1)" alt="Long Sleeve TShirt
$150.00">
    </div>
    <div class="column">
      <img class="demo cursor" src="img/product_details/prodect_details_2.png" style="width:100%" onclick="currentSlide(2)" alt="Long Sleeve TShirt 
$150.00">
    </div>
    <div class="column">
      <img class="demo cursor" src="img/product_details/prodect_details_3.png" style="width:100%" onclick="currentSlide(3)" alt="Long Sleeve TShirt
$150.00">
    </div>
    <div class="column">
      <img class="demo cursor" src="img/product_details/prodect_details_4.png" style="width:100%" onclick="currentSlide(4)" alt="Long Sleeve TShirt
$150.00">
    </div>
       
    
  </div>
</div>
                            
                 </div>
                         <div class="frist_right" style="width:40%;">
                               <h1>Faded SkyBlu Denim Jeans</h1>
                               <p class="p"><b>$150.0</b></p>
                             <br>
                             <br>
                             <p class="pa"> Category :<span>Household</span>  </p>
                             <br>
                             <p class="pa">Availibility : In Stock</p>
                            <br>
                             <br>
                             <hr>
                             <br>
                             <br>
                             <p>
                                 
                             Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that can make your interior look awesome, and at the same time.
                             </p>
                             <br>
                             
                             <div class="couter">
                                 <input type="button"value="+" onclick="pouns()" ><input id="pouns" type="text"value="1" min="1"><input type="button"value="-"onclick="minse()">
                             </div>
                             <div class="AddToCart">
                                 <p>AddToCart</p>
                             </div>
                             <div class="love"><p>&#10084;</p></div>
                             <div class="media">
                              <div class="face"><a href="https://facebook.com" target="_blank"><img src="img/icon/feature_icon_1.png" style="width:30px;height:30px"></a></div>
                                 <div class="face"><a href="https://facebook.com" target="_blank"><img src="img/icon/feature_icon_1.png" style="width:30px;height:30px"></a></div>
                                  <div class="face"><a href="https://facebook.com" target="_blank"><img src="img/icon/feature_icon_1.png" style="width:30px;height:30px"></a></div>

                             </div>
                        </div>
                 </div>
                    <div class="clear"></div>
            
            <div class="second_div">
                <div class="Description">Description</div>
           <div class="pargraph">
                 <p>Beryl Cook is one of Britain’s most talented and amusing artists .Beryl’s pictures feature women of all shapes and sizes enjoying themselves .Born between the two world wars, Beryl Cook eventually left Kendrick School in Reading at the age of 15, where she went to secretarial school and then into an insurance office. After moving to London and then Hampton, she eventually married her next door neighbour from Reading, John Cook. He was an officer in the Merchant Navy and after he left the sea in 1956, they bought a pub for a year before John took a job in Southern Rhodesia with a motor company. Beryl bought their young son a box of watercolours, and when showing him how to use it, she decided that she herself quite enjoyed painting. John subsequently bought her a child’s painting set for her birthday and it was with this that she produced her first significant work, a half-length portrait of a dark-skinned lady with a vacant expression and large drooping breasts. It was aptly named ‘Hangover’ by Beryl’s husband and

It is often frustrating to attempt to plan meals that are designed for one. Despite this fact, we are seeing more and more recipe books and Internet websites that are dedicated to the act of cooking for one. Divorce and the death of spouses or grown children leaving for college are all reasons that someone accustomed to cooking for more than one would suddenly need to learn how to adjust all the cooking practices utilized before into a streamlined plan of cooking that is more efficient for one person creating less</p>
                
                
                </div>
           </div>
                                        <div class="clear"></div>

                  <div class="BestSellers">
                      
                      <h1>BestSellers</h1>
                    <div>
                      <div class="container2">
  <img src="img/category/category_1.png" alt="Avatar" class="image2">
  <div class="overlay2">
    <div class="text2"><div class="word2">90$</div><div class="word2">&#10084;</div></div>
  </div>
</div>
              <div class="container2">
             <img src="img/category/category_2.png" alt="Avatar" class="image2">
  <div class="overlay2">
    <div class="text2"><div class="word2">90$</div><div class="word2">&#10084;</div></div>
  </div>
</div>
              <div class="container2">
             <img src="img/category/category_3.png" alt="Avatar" class="image2">
  <div class="overlay2">
    <div class="text2"><div class="word2">90$</div><div class="word2">&#10084;</div></div>
  </div>
</div>
          </div>
              <div style="width:98%">   
                <div class="container2">
  <img src="img/category/category_4.png" alt="Avatar" class="image2">
  <div class="overlay2">
    <div class="text2"><div class="word2">90$</div><div class="word2">&#10084;</div></div>
  </div>
                    </div>
                    
                  </div> 
                      
                      <div class="clear"></div>
                      
        </div>



    <script src="catocrydetails.js"></script>  
 
    
    
    <!-- Shipping  -->
    <div class="ship">
        <div class="ship-1 ship1">
            <img src="img/icon/icon_1.png">
            <h3>Fast shipping</h3>
            <p>Divided face for bearing the divide unto seed winged divided light Forth.</p>
            <div class="ship-overlay"></div>
        </div>
        
        <div class="ship-1 ship2">
            <img src="img/icon/icon_2.png">
            <h3>Fast shipping</h3>
            <p>Divided face for bearing the divide unto seed winged divided light Forth.</p>
            <div class="ship-overlay"></div>
        </div>
        <div class="ship-1 ship3">
            <img src="img/icon/icon_3.png">
            <h3>Free shipping</h3>
            <p>Divided face for bearing the divide unto seed winged divided light Forth.</p>
            <div class="ship-overlay"></div>
        </div>
        <div class="ship-1 ship4" style="float: right">
            <img src="img/icon/icon_4.png">
            <h3>Fast shipping</h3>
            <p>Divided face for bearing the divide unto seed winged divided light Forth.</p>
            <div class="ship-overlay"></div>
        </div>
        
    </div>
    
    <!-- instagram Photo -->
    <div class="instagram">
        <div class="photo">
            <img src="img/instagram/inst_1.png">
            <div class="photo-overlay">
                <a href="shopcatogry.php"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        
        <div class="photo">
            <img src="img/instagram/inst_2.png">
            <div class="photo-overlay">
                <a href="shopcatogry.php"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        
        <div class="photo photo-3">
            <img src="img/instagram/inst_3.png">
            <div class="photo-overlay">
                <a href="shopcatogry.php"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        
        <div class="photo photo-4">
            <img src="img/instagram/inst_4.png">
            <div class="photo-overlay">
                <a href="shopcatogry.php"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        
        <div class="photo photo-last">
            <img src="img/instagram/inst_5.png">
            <div class="photo-overlay">
                <a href="shopcatogry.php"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        
        <div class="clear"></div>
    </div>
    
    <!-- Footer -->
    <div class="foot">
        <div class="content">
            <div class="foot-row">
                <h4>Category</h4>
                <ul>
                    <li><a href="shopcatogry.php">Male</a></li>
                    <li><a href="shopcatogry.php">Female</a></li>
                    <li><a href="shopcatogry.php">Fashion</a></li>
                    <li><a href="shopcatogry.php">Shoes</a></li>
                </ul>
            </div>
            
            <div class="foot-row">
                <h4>Company</h4>
                <ul>
                    <li><a href="shopcatogry.php">About</a></li>
                    <li><a href="shopcatogry.php">News</a></li>
                    <li><a href="shopcatogry.php">FAQ</a></li>
                    <li><a href="shopcatogry.php">Contact</a></li>
                </ul>
            </div>
            
            <div class="foot-row">
                <h4>Address</h4>
                <ul>
                    <li><a href="#">200, blue block, NewYork</a></li>
                    <li><a href="#">+10 456 267 1678</a></li>
                    <li><a href="#">Contact89@Winter.Com</a></li>
                </ul>
            </div>
            
            <div class="foot-row foot-row-last">
                <h4>Newsletter</h4>
                <form>  
                    <input placeholder="Email Address" type="email">
                    <button>Subscribe</button>
                </form>
                
            </div>
            <div class="clear"></div>
             

    
        <div class="copyright_text">
            <p>Copyright &copy;2019 All rights reserved | This template is made by sara mohamed </p>
        </div>
        
        
<!--        <div class="clear"></div>-->
        
    </div>
            </div>                          
   </body>
</html>