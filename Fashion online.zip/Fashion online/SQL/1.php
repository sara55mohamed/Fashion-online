<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <form action="2.php" method="post">
        name<br>
    <input type="text" name="name"><br>
    phone<br>
    <input type="text" name="phone"><br>
    <input type="submit" value="show" name="">
</form>
        </body>
</html>